'''
Wen Ou (Student Number 1008001127)

The accounts database 
'''

import sqlite3

class AccountsDB:
    def __init__(self) -> None:
        self.create_accounts_db() 

    def create_accounts_db(self):
        '''
        Create the database if not exists.
        '''
        conn = sqlite3.connect('accounts.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS accounts
                    (username TEXT, password TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
        conn.commit()
        conn.close()
    
    def insert_user(self, username, password):
        '''
        Insert a new user row
        '''
        conn = sqlite3.connect('accounts.db')
        c = conn.cursor()
        c.execute("INSERT INTO accounts (username, password) VALUES (?,?)", (username, password))
        conn.commit()
        conn.close()
    
    def verify_username_valid(self, username):
        '''
        Return true if the username exists in the database; false otherwise.
        '''
        conn = sqlite3.connect('accounts.db')
        c = conn.cursor()
        c.execute("SELECT * FROM accounts WHERE username=?", (username, ))
        return c.fetchone()

    def verify_login(self, username, password):
        '''
        Return true if the username and password exist in the database and match; false otherwise.
        '''
        conn = sqlite3.connect('accounts.db')
        c = conn.cursor()
        c.execute("SELECT * FROM accounts WHERE username=? AND password=?", (username, password))
        return c.fetchone()

