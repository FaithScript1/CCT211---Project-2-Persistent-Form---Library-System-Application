'''
Wen Ou (Student Number 1008001127)

The Login Page
'''

import tkinter as tk
from tkinter import ttk, messagebox
from src.styles import fonts

        
class LoginPage(ttk.Frame):
    def __init__(self, parent, controller):
        '''
        Set up the layout for the Login page.
        '''
        ttk.Frame.__init__(self, parent)
        self.controller = controller
        
        self.configure(padding=(20, 10))
        self.columnconfigure(2, weight=1)
        
        self.username = tk.StringVar(value='', name='Username')
        self.password = tk.StringVar(value='', name='Password')
        self.show_password = tk.IntVar(value=0) 
        
        ttk.Label(self, text ="Log in / Sign up", font=fonts.H1).grid(columnspan=3, pady=10)
        
        ttk.Label(self, text="Username").grid(row=1, column=0, sticky='ew', pady=10, padx=(0, 10))
        ttk.Entry(self, textvariable=self.username).grid(row=1, column=1, columnspan=2, sticky='ew')

        ttk.Label(self, text="Password").grid(row=2, column=0, sticky='ew', pady=10, padx=(0, 10))
        self.password_entry = ttk.Entry(self, textvariable=self.password, show='*')
        self.password_entry.grid(row=2, column=1, columnspan=2, sticky='ew')
        
        ttk.Checkbutton(
            self, text="Show Password", variable=self.show_password, 
            command=lambda: self.password_entry.config(show='' if self.show_password.get() else '*')
        ).grid(row=3, column=1, sticky='w')
        
        ttk.Button(
            self, text='Log in', style='success.TButton', 
            command=self.handle_submit_login
        ).grid(row=4, column=0, sticky='ew', pady=10, padx=(0, 10))
        
        ttk.Button(
            self, text='Sign up', style='success.TButton', 
            command=self.handle_submit_signup
        ).grid(row=4, column=1, sticky='ew', pady=10, columnspan=1)

        ttk.Button(self, text='Cancel', style='danger.TButton', 
                   command=lambda: controller.set_frame("MainPage"))\
                       .grid(row=5, column=2, sticky='e', pady=10, padx=(0, 10))


    def handle_submit_login(self):
        '''
        Handler of action 'login'
        '''
        username = self.username.get()
        pwd = self.password.get()
        print(username, pwd)
        
        if self.controller.accounts_db.verify_login(username, pwd):
            messagebox.showinfo("Login Info", "Login Successful")
        else:
            messagebox.showerror("Login Info", "Login Failed")
            
            
    def handle_submit_signup(self):
        '''
        Handler of action 'sign up'
        '''
        username = self.username.get()
        pwd = self.password.get()
        print(username, pwd)
        
        # verify if the username is occupied; if not:
        # - prompt the user to confirm signing up the new account
        # - insert the new account data to the accounts database
        if self.controller.accounts_db.verify_username_valid(username):
            messagebox.showerror("Signup Info", "Username already used")
        else:
            resp = messagebox.askyesno('Confirm', 'Do you want to create this new account?')
            if resp:
                self.controller.accounts_db.insert_user(username, pwd)
                messagebox.showinfo("Signup Info", 'Your account is successfully created!')
        
