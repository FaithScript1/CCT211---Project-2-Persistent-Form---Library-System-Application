'''
Boyuan Zhang (Student Number 1009153675 )

The BooksPage
'''
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

class BooksPage:
        
    def create_main_window(self):
        window = tk.Tk()
        window.title("BookPage")
        window.geometry("800x600")
        
        

        def show_guide():
            messagebox.showinfo("Guide", "Welcome to the Library Management System! This is a system used for managing libraries.")

        def show_features():
            messagebox.showinfo("Features", "This system provides the following features:\n\n1. Add books\n2. Delete books\n")

        def show_support():
            messagebox.showinfo("Support", "If you encounter any issues while using the system, please contact our technical support team.")

        def show_faq():
            messagebox.showinfo("FAQ", "Q: How to add books?\nA: Click the \"Add books\" button and enter the relevant information of the book.\n\nQ: How to delete books?\nA: Select the book to be deleted and click the \"Delete books\" button.\n")

        def view_books():

            conn = sqlite3.connect('books.db')
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM books")
            books = cursor.fetchall()
            conn.close()

            book_window = tk.Toplevel(window)
            book_window.title("Books")
            book_window.geometry("600x400")

            canvas = tk.Canvas(book_window)
            canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

            scrollbar = tk.Scrollbar(book_window, command=canvas.yview)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            canvas.configure(yscrollcommand=scrollbar.set)

            book_frame = tk.Frame(canvas)
            book_frame.pack(side=tk.TOP)

            canvas.create_window((0, 0), window=book_frame, anchor=tk.NW)
            book_frame.bind("<Configure>", lambda event: canvas.configure(scrollregion=canvas.bbox("all")))

            for book in books:
                book_block = tk.Frame(book_frame, relief=tk.RAISED, bd=2)
                book_block.pack(pady=10)

                book_info = f"Book ID: {book[0]}\nName: {book[1]}\nISBN: {book[2]}\nStatus: {book[3]}\nAuthor: {book[4]}"
                book_block.book_id = book[0]

                book_label = tk.Label(book_block, text=book_info)
                book_label.pack(side=tk.LEFT, padx=10)

                modify_button = tk.Button(book_block, text="Modify", command=lambda book_id=book[0]: modify_book(book_id))
                modify_button.pack(side=tk.LEFT, padx=5)

                delete_button = tk.Button(book_block, text="Delete", command=lambda block=book_block: delete_book(block))
                delete_button.pack(side=tk.LEFT, padx=5)

                collect_button = tk.Button(book_block, text="Collect")
                collect_button.pack(side=tk.LEFT, padx=5)

            add_button = tk.Button(book_window, text="Add Book", command=lambda: add_book())
            add_button.pack()

        def modify_book(book_id):

            conn = sqlite3.connect('books.db')
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM books WHERE id=?", (book_id,))
            book = cursor.fetchone()
            conn.close()

            modify_window = tk.Toplevel(window)
            modify_window.title("Modify Book")
            modify_window.geometry("400x300")

            label_book_id = tk.Label(modify_window, text="Book ID:")
            label_book_id.pack()

            entry_book_id = tk.Entry(modify_window)
            entry_book_id.insert(tk.END, book[0])
            entry_book_id.config(state=tk.DISABLED)
            entry_book_id.pack()

            label_book_name = tk.Label(modify_window, text="Book Name:")
            label_book_name.pack()

            entry_book_name = tk.Entry(modify_window)
            entry_book_name.insert(tk.END, book[1])
            entry_book_name.pack()

            label_isbn = tk.Label(modify_window, text="ISBN:")
            label_isbn.pack()

            entry_isbn = tk.Entry(modify_window)
            entry_isbn.insert(tk.END, book[2])
            entry_isbn.pack()

            label_status = tk.Label(modify_window, text="Status:")
            label_status.pack()

            entry_status = tk.Entry(modify_window)
            entry_status.insert(tk.END, book[3])
            entry_status.pack()

            label_author = tk.Label(modify_window, text="Author:")
            label_author.pack()

            entry_author = tk.Entry(modify_window)
            entry_author.insert(tk.END, book[4])
            entry_author.pack()
            def update_book(book_id, book_name, isbn, status, author):
                conn = sqlite3.connect('books.db')
                cursor = conn.cursor()
                cursor.execute("UPDATE books SET name=?, isbn=?, status=?, author=? WHERE id=?", (book_name, isbn, status, author, book_id))
                conn.commit()
                conn.close()

                messagebox.showinfo("Success", "Book updated successfully.")
                modify_window.destroy()
            
            def cancel_update():
                messagebox.showinfo("Cancel", "You have canceled the modification.")
                modify_window.destroy()

            update_button = tk.Button(modify_window, text="Update", command=lambda: update_book(book_id, entry_book_name.get(), entry_isbn.get(), entry_status.get(), entry_author.get()))
            update_button.pack()
            cancel_button = tk.Button(modify_window, text="Cancel", command=lambda: cancel_update())
            cancel_button.pack()

            
                


        def delete_book(book_block):
            book_id = book_block.book_id
            conn = sqlite3.connect('books.db')
            cursor = conn.cursor()
            cursor.execute("DELETE FROM books WHERE id=?", (book_id,))
            conn.commit()
            conn.close()

            book_block.pack_forget()
            messagebox.showinfo("Success", "Book deleted successfully.")

        def add_book():

            add_window = tk.Toplevel(window)
            add_window.title("Add Book")
            add_window.geometry("400x300")

            label_book_name = tk.Label(add_window, text="Book Name:")
            label_book_name.pack()

            entry_book_name = tk.Entry(add_window)
            entry_book_name.pack()

            label_isbn = tk.Label(add_window, text="ISBN:")
            label_isbn.pack()

            entry_isbn = tk.Entry(add_window)
            entry_isbn.pack()

            label_status = tk.Label(add_window, text="Status:")
            label_status.pack()

            entry_status = tk.Entry(add_window)
            entry_status.pack()

            label_author = tk.Label(add_window, text="Author:")
            label_author.pack()

            entry_author = tk.Entry(add_window)
            entry_author.pack()

            

            def save_book(book_name, isbn, status, author):
                conn = sqlite3.connect('books.db')
                cursor = conn.cursor()
                cursor.execute("INSERT INTO books (name, isbn, status, author) VALUES (?, ?, ?, ?)", (book_name, isbn, status, author))
                conn.commit()
                conn.close()

                messagebox.showinfo("Success", "Book added successfully.")
                add_window.destroy()
            
            def cancel_save():
                messagebox.showinfo("Cancel", "You have canceled the adding.")
                add_window.destroy()

            save_button = tk.Button(add_window, text="Save", command=lambda: save_book(entry_book_name.get(), entry_isbn.get(), entry_status.get(), entry_author.get()))
            save_button.pack()
            cancel_button = tk.Button(add_window, text="Cancel", command=lambda: cancel_save())
            cancel_button.pack()
            
        button_frame = tk.Frame(window)
        button_frame.pack(side=tk.BOTTOM, pady=20)

        view_button = tk.Button(button_frame, text="View Books", command=view_books)
        view_button.pack(side=tk.LEFT, padx=10)

        guide_button = tk.Button(button_frame, text="Guide", command=show_guide)
        guide_button.pack(side=tk.LEFT, padx=10)

        features_button = tk.Button(button_frame, text="Features", command=show_features)
        features_button.pack(side=tk.LEFT, padx=10)

        support_button = tk.Button(button_frame, text="Support", command=show_support)
        support_button.pack(side=tk.LEFT, padx=10)

        faq_button = tk.Button(button_frame, text="FAQ", command=show_faq)
        faq_button.pack(side=tk.LEFT, padx=10)

