'''
Tianchi Du (Student Number 1008179007)

The Main Page /Search engine
'''

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from src.styles import fonts
from src.pages.BooksPage import BooksPage
import subprocess
import os


# Function to search the library.db for books
def search_library_db(search_term):
    conn = sqlite3.connect('library.db')
    c = conn.cursor()
    c.execute("SELECT * FROM books_according_to_author WHERE Book_Title LIKE ?", ('%' + search_term + '%',))
    results = c.fetchall()
    conn.close()
    return results

# Function to search the account file for account information

class MainPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, background='light gray')  
        self.controller = controller
        
        # Instantiate BooksPage (assuming BooksPage does not require any arguments)
        self.bookpage = BooksPage()
        
        # Main page title
        label = tk.Label(self, text="Main Page", font=fonts.H1, bg='light gray')  
        label.pack(pady=20)
        
        # Setup search functionality
        self.setup_search()
        
        # Setup navigation buttons
        self.setup_navigation_buttons()
        
        # Setup library buttons
        self.setup_library_button()
        
        # Add Read Me button
        self.setup_read_me_button()
        
    def setup_search(self):
        # Search box and search button settings
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(self, textvariable=self.search_var)
        search_entry.pack(pady=10)
        search_button = ttk.Button(self, text="Search", command=self.perform_search)
        search_button.pack(pady=10)

    def perform_search(self):
        """Perform a search operation."""
        search_term = self.search_var.get().strip()
        if not search_term:
            messagebox.showinfo("Error", "Please enter a search term.")
            return
        book_results = search_library_db(search_term)  # Call previously defined functions
        if book_results:
            results_str = "\n".join([f"Title: {row[1]}, Author: {row[0]}, Year: {row[2]}" for row in book_results])
            messagebox.showinfo("Search Result", f"Books Found:\n{results_str}")
        else:
            messagebox.showinfo("Search Result", "No books found matching the search criteria.")

            
    def setup_navigation_buttons(self):
        """Set up navigation buttons."""
        info_page_button = ttk.Button(self, text="Info Page", command=lambda: self.controller.set_frame("InfoPage"))
        info_page_button.pack(pady=10)
        login_button = ttk.Button(self, text="Login / Sign up", command=lambda: self.controller.set_frame("LoginPage"))
        login_button.pack(pady=10)
        books_button = ttk.Button(self, text="Books", command=self.bookpage.create_main_window)
        books_button.pack(pady=10)
        
    def setup_library_button(self):
        """Setup the button to open the LibraryPage."""
        library_button = ttk.Button(self, text="Open Library", command=self.open_library)
        library_button.pack(pady=10)  # Uses the same pady parameter as other buttons
            
    def open_library(self):
        """Launches the LibraryPage.py script."""
        library_page_path = os.path.join(os.path.dirname(__file__), "LibraryPage.py")
        subprocess.call(["python3", library_page_path])
        
    def setup_read_me_button(self):
        """Add the Read Me button and its functionality."""
        read_me_button = ttk.Button(self, text="Read Me", command=self.show_read_me)
        read_me_button.pack(pady=10)
        
        
    def show_read_me(self):
        """Display the Read Me information"""
        read_me_text = """
        Welcome to the Main Page!
        
        Here you can navigate to different pages like Books, Library, and more.
        
        - Use the 'Search' to find specific topics or books.
        - Visit the 'Library' to browse available books.
        - Check out 'Books' for add your books！
        - Need help? Go to 'Info Page'.
        - To access personal features, use 'Login / Sign up'.
        
        Enjoy exploring!
        """
        messagebox.showinfo("Read Me", read_me_text)
