'''
Caroline Tume (Student Number 1009253086)

List of websites I visited to learn more about certain modules/libraries:
    Dataquest:
        https://www.dataquest.io/blog/tutorial-an-introduction-to-python-requests-library/#:~:text=The%20Requests%20library%20provides%20a%20simple%20API%20for,a%20specific%20web%20server%20specified%20by%20its%20URL
    Geeks for Geeks:
        https://www.geeksforgeeks.org/python-pillow-tutorial/?ref=lbp
        https://www.geeksforgeeks.org/create-temporary-files-and-directories-using-python-tempfile/
    GitHub:
        https://github.com/pymupdf/PyMuPDF
    Python:
        https://docs.python.org/3/library/tempfile.html
    Read the Docs:
        https://pymupdf.readthedocs.io/en/latest/tutorial.html
    Stack Overflow:
        https://stackoverflow.com/questions/63259157/adding-text-to-a-pdf-using-pymupdf
        https://stackoverflow.com/questions/39983886/python-writing-and-reading-from-a-temporary-file
    W3Schools:
        https://www.w3schools.com/SQl/default.asp
        https://www.w3schools.com/python/module_requests.asp
        https://www.w3schools.com/python/module_os.asp
'''


from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
import sqlite3
import fitz  # PyMuPDF
import requests
import tempfile
import os



class Database:
    '''
    The purpose of this class is to create and open the database "library.db", which holds all of the book information.
    
    '''
    def __init__(self):
        # Initialize the database connection and cursor.
        self.conn = sqlite3.connect('library.db')
        self.cur = self.conn.cursor()
    
    def create_table(self):
        # Drop the table if it exists and create a new table (if it does not exist) to store book information.
        self.cur.execute('''DROP TABLE IF EXISTS "books_according_to_author";''')
        self.cur.execute('''CREATE TABLE IF NOT EXISTS "books_according_to_author"
        (
            "Author_Name" TEXT NOT NULL, 
            "Book_Title" TEXT NOT NULL, 
            "Year_Released" INTEGER NOT NULL, 
            "ISBN" INTEGER NOT NULL,
            "PDF_URL" TEXT,
            PRIMARY KEY("Author_Name", "Book_Title")
        );''')
    
    def insert_data(self):
        # Insert data into the database's table.
        self.cur.execute('''INSERT INTO "books_according_to_author" 
        (Author_Name, Book_Title, Year_Released, ISBN, PDF_URL) VALUES 
        ("Asato Asato", "86—EIGHTY-SIX, Vol. 1", 2017, 9781975303129, "https://dn720003.ca.archive.org/0/items/berserk-of-gluttony-light-novel-vol.-4_202210/86%E2%80%94EIGHTY-SIX%2C%20Vol.%201.pdf"),
        ("Asato Asato", "86—EIGHTY-SIX, Vol. 2", 2017, 9781975303143, "https://dn720003.ca.archive.org/0/items/berserk-of-gluttony-light-novel-vol.-4_202210/86%E2%80%94EIGHTY-SIX%2C%20Vol.%202.pdf"),
        ("Asato Asato", "86—EIGHTY-SIX, Vol. 3", 2017, 9781975303112, "https://dn720003.ca.archive.org/0/items/berserk-of-gluttony-light-novel-vol.-4_202210/86%E2%80%94EIGHTY-SIX%2C%20Vol.%203.pdf"),
        ("Asato Asato", "86—EIGHTY-SIX, Vol. 4", 2018, 9781975303167, "https://dn720003.ca.archive.org/0/items/berserk-of-gluttony-light-novel-vol.-4_202210/86%E2%80%94EIGHTY-SIX%2C%20Vol.%204.pdf"),
        ("Asato Asato", "86—EIGHTY-SIX, Vol. 5", 2018, 9781975399252, "https://dn720003.ca.archive.org/0/items/berserk-of-gluttony-light-novel-vol.-4_202210/86%E2%80%94EIGHTY-SIX%2C%20Vol.%205.pdf"),
        ("Fred Gipson", "Old Yeller", 1956, 9780061962868, "https://mrbreckenridge.weebly.com/uploads/5/9/7/4/59745285/old_yeller_book.pdf"),
        ("Stephen King", "Carrie", 1974, 9780450018626, "https://ia601405.us.archive.org/6/items/stephen-king_202206/Stephen%20King%20-%201974%20-%20Carrie.pdf"),
        ("Stephen King", "The Shining", 1977, 9780385121675, "https://dn720004.ca.archive.org/0/items/stephen-king_202206/Stephen%20King%20-%20The%20Shining%2001%20-%20The%20Shining.pdf"),
        ("Stephen King", "Firestarter", 1980, 9781668009925, "https://dn720004.ca.archive.org/0/items/stephen-king_202206/Stephen%20King%20-%201980%20-%20Firestarter.pdf"),
        ("Stephen King", "Cujo", 1981, 9780670451937, "https://ia801405.us.archive.org/6/items/stephen-king_202206/Stephen%20King%20-%201981%20-%20Cujo.pdf"),
        ("Stephen King", "The Mist", 1981, 9781982103521, "https://dn720004.ca.archive.org/0/items/stephen-king_202206/Stephen%20King%20-%201981%20-%20The%20Mist.pdf"),
        ("Stephen King", "Christine", 1983, 9780451167802, "https://dn720004.ca.archive.org/0/items/stephen-king_202206/Stephen%20King%20-%201983%20-%20Christine.pdf"),
        ("Stephen King", "Pet Sematary", 1983, 9780670743705, "https://archive.org/download/stephen-king_202206/Stephen%20King%20-%201983%20-%20Pet%20Sematary.pdf"),
        ("Stephen King", "In the Tall Grass", 2012, 9781439193975, "https://archive.org/download/stephen-king_202206/Stephen%20King%20-%20Novella%20-%202012%20-%20In%20the%20Tall%20Grass.pdf"),
        ("Stephen King", "Doctor Sleep", 2013, 9781476727653, "https://ia601405.us.archive.org/6/items/stephen-king_202206/Stephen%20King%20-%20The%20Shining%2002%20-%20Doctor%20Sleep.pdf")''')
        
        self.conn.commit()
    
    def get_authors(self):
        # Retrieve a list of distinct author names from the database.
        self.cur.execute("SELECT DISTINCT Author_Name FROM books_according_to_author")
        authors = self.cur.fetchall()
        return [author[0] for author in authors]
    
    def get_books_by_author(self, author_name):
        # Retrieve all books by a specific author.
        self.cur.execute("SELECT * FROM books_according_to_author WHERE Author_Name=?", (author_name,))
        books = self.cur.fetchall()
        return books
    
    def close_connection(self):
        # Close the database connection.
        self.conn.close()


class Library_GUI:
    '''
    The purpose of this class is to access and display the information from "library.db" into a TreeView.
    This is done according to author name, with the book titles being organized in alphabetical order.
    The user can open a pdf by clicking on the book the user wants to read from the TreeView.
    '''
    def __init__(self, root):
        # Initialize the GUI window and set its attributes.
        self.root = root
        self.root.title("Books According to Author Name")
        self.root.geometry("1100x600")
        
        # Initialize the Database object.
        self.database = Database()
        
        # Create a frame to contain both the label and the TreeView widget.
        self.frame = Frame(root, height=20)
        self.frame.pack(fill=BOTH, expand=True)
        
        # Add a label widget to instruct the user how to use the library.
        self.info_label = Label(self.frame, text="Note: You may need to click twice to open the PDF.")
        self.info_label.pack(side=TOP)
        
        # Create the TreeView widget to display book information (based on the author of the specific work).
        self.tree = ttk.Treeview(self.frame, columns=("Book Title", "Year Released", "ISBN", "PDF URL"), selectmode="extended")
        self.tree.heading('#0', text='Author Name')
        self.tree.heading('#1', text='Book Title')
        self.tree.heading('#2', text='Year Released')
        self.tree.heading('#3', text='ISBN')
        self.tree.heading('#4', text='PDF URL')
        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        
        # Add scrollbar to the Treeview widget
        self.v_scrollbar = Scrollbar(self.frame, orient="vertical", command=self.tree.yview)
        self.v_scrollbar.pack(side=RIGHT, fill=Y)
        self.tree.configure(yscrollcommand=self.v_scrollbar.set)
        
        # Connect to the database, load the data, and close the connection.
        self.connect_database()
        self.load_data()
        self.database.close_connection()
        
        # Bind the on_click method to the left mouse button click event on the TreeView widget.
        self.tree.bind('<Button-1>', self.on_click)
    
    def connect_database(self):
        # Create table and insert data into the database.
        self.database.create_table()
        self.database.insert_data()
    
    def load_data(self):
        # Load data from the database and populate the TreeView widget.
        authors = self.database.get_authors()
        for author in authors:
            author_name = author
            author_node = self.tree.insert('', 'end', text=author_name)

            books = self.database.get_books_by_author(author_name)
            for book in books:
                book_title, year_released, isbn, pdf_url = book[1:]
                self.tree.insert(author_node, 'end', text="", values=(book_title, year_released, isbn, pdf_url))
    
    def on_click(self, event):
        # Open the selected PDF URL in the PDF Viewer.
        if self.tree.selection():
            item = self.tree.selection()[0]
            values = self.tree.item(item, 'values')
            if values:
                pdf_url = values[-1]  # The last value is the PDF URL.
                pdf_viewer = PDFViewer(Toplevel(), pdf_url) 


class PDFViewer:
    '''
    The purpose of this class is to allow the user to read the pdf of their choice.
    The pdf is accessed by clicking on the book the user wants to read from the TreeView.
    '''
    def __init__(self, root, pdf_url):
        # Initialize the PDF Viewer window and set its attributes.
        self.root = root
        self.root.title("PDF Viewer")
        self.root.geometry("620x600")
        
        # Label to display instructions
        self.instruction_label = Label(self.root, text="Use the up and down arrow keys to quickly flip between pages.\n"
                                                         "Use the scrollbar on the bottom left of the screen to manually scroll the current page.\n"
                                                         "Use '⬆ load previous page' and '⬇ load next page' to manually load the page.")
        self.instruction_label.pack(anchor=N, fill="x")
        
        # Store the PDF URL.
        self.pdf_url = pdf_url
        self.temp_pdf_path = None  # Temporary path to store the downloaded PDF.
        self.images = []  # Store images of PDF pages.
        self.current_page = 0  # Index of the current page being displayed.
        
        # Download and open the PDF.
        self.download_and_open_pdf()
        self.create_navigation_buttons()
        
        # Bind the on_close method to the window close event.
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # Bind arrow keys for quick scrolling.
        self.root.bind("<Up>", self.scroll_to_previous_page)
        self.root.bind("<Down>", self.scroll_to_next_page)
    
    def download_and_open_pdf(self):
        # Download the PDF (temporarily) and open it.
        try:
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as temp_pdf:
                response = requests.get(self.pdf_url)
                temp_pdf.write(response.content)
                self.temp_pdf_path = temp_pdf.name  # Save the temporary file path.
            
            # Open the PDF and create a frame for each page.
            doc = fitz.open(self.temp_pdf_path)
            self.frame = Frame(self.root)
            self.frame.pack(fill=BOTH, expand=True)
            self.canvas = Canvas(self.frame, bg="white")
            self.canvas.pack(fill=BOTH, expand=True)
            
            # Add a vertical scrollbar to the canvas.
            scrollbar = Scrollbar(self.frame, orient=VERTICAL, command=self.canvas.yview)
            scrollbar.pack(side="left", fill="y")
            self.canvas.configure(yscrollcommand=scrollbar.set)
            
            # Create a canvas for each page of the PDF.
            self.frames = []
            self.canvases = []
            self.create_canvas_for_each_page(doc)
            self.current_page = 0
            self.show_current_page()

        except Exception as e:
            # Error handling.
            print("Error loading PDF:", e)
    
    def create_canvas_for_each_page(self, doc):
        total_height = 0
        # Iterate through each page of the PDF.
        for page_number in range(len(doc)):
            page = doc.load_page(page_number)
            page_width, page_height = page.bound()[2], page.bound()[3]
            
            # Create a frame for the page and embed it into the canvas.
            frame = Frame(self.canvas, width=page_width, height=page_height)
            self.canvas.create_window((0, total_height), window=frame, anchor=NW)
            canvas = Canvas(frame, width=page_width, height=page_height, bg="black")
            canvas.pack(fill=BOTH, expand=True)
            self.canvases.append(canvas)
            
            # Convert the page to an image and display it on the canvas.
            pix = page.get_pixmap()
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            photo = ImageTk.PhotoImage(img)
            self.images.append(photo)
            canvas.create_image(0, 0, anchor=NW, image=photo)

            total_height += page_height
        
        # Configure the scroll region of the canvas.
        self.canvas.config(scrollregion=(0, 0, self.canvases[0].winfo_width(), total_height))
    
    def create_navigation_buttons(self):
        # Create buttons for navigating between pages.
        self.prev_button = Button(self.root, text='⬆ load previous page', command=self.show_previous_page)
        self.prev_button.pack(side='left')

        self.next_button = Button(self.root, text='⬇ load next page', command=self.show_next_page)
        self.next_button.pack(side='left')
    
    def show_previous_page(self):
        # Display the previous page of the PDF.
        if self.current_page > 0:
            self.current_page -= 1
            self.show_current_page()
    
    def show_next_page(self):
        # Display the next page of the PDF.
        if self.current_page < len(self.images) - 1:
            self.current_page += 1
            self.show_current_page()
    
    def show_current_page(self):
        # Show the current page on the canvas (cannot tell if implemented due to accessibility settings).
        for canvas in self.canvases:
            canvas.pack_forget()
        self.canvases[self.current_page].pack(fill=BOTH, expand=True)
    
    def on_close(self):
        # Close the PDF Viewer window and delete the temporary PDF file.
        if self.temp_pdf_path and os.path.exists(self.temp_pdf_path):
            os.remove(self.temp_pdf_path)
        self.root.destroy()
    
    
    def scroll_to_previous_page(self, event):
        # Scroll to the previous page using arrow keys for quick scrolling.
        if self.current_page > 0:
            page_height = self.canvases[self.current_page - 1].winfo_height()
            self.canvas.yview_moveto(self.current_page / len(self.canvases))
            self.root.update_idletasks()  # Ensure that the canvas has updated its scroll region.
            self.canvas.yview_scroll(-1, "pages")
            self.show_previous_page()  # Load the previous page.
    
    def scroll_to_next_page(self, event):
        # Scroll to the next page using arrow keys for quick scrolling.
        if self.current_page < len(self.images) - 1:
            page_height = self.canvases[self.current_page + 1].winfo_height()
            self.canvas.yview_moveto(self.current_page / len(self.canvases))
            self.root.update_idletasks()  # Ensure that the canvas has updated its scroll region.
            self.canvas.yview_scroll(1, "pages")
            self.show_next_page()  # Load the next page.


if __name__ == '__main__':
    database = Database()
    root = Tk()
    app = Library_GUI(root)
    root.mainloop()