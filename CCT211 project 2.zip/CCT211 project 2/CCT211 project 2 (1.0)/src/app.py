'''
Wen Ou (Student Number 1008001127)

This is the entry point of the app:
1. Set up the window and the main container;
2. Set up the databases;
3. The app uses the multi-frame framework: 
    a. Load all the frames (pages) to be used later;
    b. Use set_frame() to switch the frame to be displayed;
4. The app uses a cache to store all temporary data while running, e.g. user data
'''

import tkinter as tk
from tkinter import ttk
from src.pages.MainPage import MainPage
from src.pages.InfoPage import InfoPage
from src.pages.LoginPage import LoginPage
from src.database.AccountsDB import AccountsDB
# from src.pages.BooksPage import BooksPage
# from src.pages.LibraryPage import LibraryPage


PAGES = [
    MainPage,
    LoginPage,
    InfoPage,
    
]
        
        
class App(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        
        # set up the layout
        self.geometry("800x600")
        self.title("Library Management System")
        
        container = ttk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight = 1)
        container.grid_columnconfigure(0, weight = 1)
        
        # set up the databases
        # TODO: init library db, etc.
        self.accounts_db = AccountsDB()
        
        # initialize the frames and cache using dict
        self.frames = {}
        self.cache = {
            'user_data': None
        }
        
        # load the frames 
        for page in PAGES:
            frame = page(parent=container, controller=self)
            self.frames[page.__name__] = frame
            frame.grid(row=0, column=0, sticky="nsew")
        
        self.set_frame("MainPage")
        

    def set_frame(self, page_name):
        '''
        Set the current frame (page) to be displayed.
        '''
        print(f"Switching to {page_name}")
        frame: tk.Frame = self.frames[page_name]
        frame.tkraise()


def main():
    app = App()
    app.mainloop()
