'''
Wen Ou (Student Number 1008001127)

The Info Page
'''

import tkinter as tk
from tkinter import ttk
from src.styles import fonts


class InfoPage(ttk.Frame):
    def __init__(self, parent, controller):
        ttk.Frame.__init__(self, parent)
        self.controller = controller
        
        # Canvas setup
        canvas = tk.Canvas(self)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        self.content_frame = ttk.Frame(canvas)
        self.content_frame.configure(padding=(20, 10))
        self.content_frame.columnconfigure(2, weight=1)
        
        # Configure canvas
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        canvas.create_window((0, 0), window=self.content_frame, anchor="nw")
        
        self.add_contents(controller)

    def add_contents(self, controller):
        ttk.Label(self.content_frame, text="Info Page", font=fonts.H1)\
            .grid(columnspan=3, pady=10)
        
        next_row = 1
        ttk.Separator(self.content_frame, orient='horizontal')\
            .grid(row=next_row, column=0, columnspan=3, sticky='ew')
        next_row += 1

        ttk.Label(self.content_frame, text="About the Library Management System", font=fonts.H2)\
            .grid(row=next_row, column=0, sticky='ew', pady=10, padx=(0, 10))
        ttk.Label(self.content_frame, text=ABOUT_PARAGRAPH, font=fonts.BODY, wraplength=750)\
            .grid(row=next_row + 1, column=0, sticky='ew')
        next_row += 2
            
        ttk.Separator(self.content_frame, orient='horizontal')\
            .grid(row=next_row, column=0, columnspan=3, sticky='ew')
        ttk.Label(self.content_frame, text="Key Features", font=fonts.H2)\
                .grid(row=next_row + 1, column=0, sticky='ew', pady=10, padx=(0, 10))
        next_row += 2
                
        for feature, p in FEATURES_PARAGRAPHS.items():
            ttk.Label(self.content_frame, text=feature, font=fonts.H4)\
                .grid(row=next_row, column=0, sticky='ew', pady=10, padx=(0, 10))
            ttk.Label(self.content_frame, text=p, font=fonts.BODY, wraplength=750)\
                .grid(row=next_row + 1, column=0, sticky='ew', padx=(20, 10))
            next_row += 2
        
        ttk.Separator(self.content_frame, orient='horizontal')\
            .grid(row=next_row, column=0, columnspan=3, sticky='ew', pady=20)
        ttk.Label(self.content_frame, text="Frequently Asked Questions (FAQ)", font=fonts.H2)\
                .grid(row=next_row + 1, column=0, sticky='ew', pady=10, padx=(0, 10))
        next_row += 2
        
        for faq, p in FAQ_PARAGRAPHS.items():
            ttk.Label(self.content_frame, text=faq, font=fonts.H4)\
                .grid(row=next_row, column=0, sticky='ew', pady=10, padx=(0, 10))
            ttk.Label(self.content_frame, text=p, font=fonts.BODY, wraplength=750)\
                .grid(row=next_row + 1, column=0, sticky='ew', padx=(20, 10))
            next_row += 2
            
        ttk.Button(self.content_frame, text='Back', style='danger.TButton', 
                   command=lambda: controller.set_frame("MainPage"))\
                       .grid(row=next_row, column=0, sticky='e', pady=10, padx=(0, 10))


ABOUT_PARAGRAPH = '''
Welcome to our Library Management System, designed to enhance your reading experience by simplifying the management of your personal book collection. Our user-friendly application is crafted to support you in organizing, tracking, and managing your books with ease, whether you're looking to dive into your next great read or keep track of your favorite titles.
'''

FEATURES_PARAGRAPHS = {
    "Book Collection Management": '''Add new books to your collection, view your entire library at a glance, and update or remove books as your collection evolves.''',
    "Efficient Book Search": '''Locate the exact book you're looking for with our advanced search filters, including title, author, and genre.''',
    "Book Access Options": '''Explore various access methods for each book, from purchasing to limited-time reading, tailored to fit your reading habits.''',
    "User Account Management": '''Personalize your experience by creating an account to track your reading history and activities.''',
    "Community Engagement": '''Join book clubs, participate in forums, and connect with a community of readers sharing your interests.'''
}

FAQ_PARAGRAPHS = {
    "How do I add a book to my collection?":
    '''To add a book, simply navigate to the "Add Book" section, where you can enter details like title, author, ISBN, etc. Once entered, click "Submit" to add the book to your collection.''',

    "Can I track my reading habits?":
    '''Yes! By creating a user account, you can track your reading history and habits, view your recently read books, and even see how often you read.''',

    "How does the search function work?":
    '''Our search function allows you to filter books by title, author, genre, and more. Just enter your search criteria in the "Search" section to find exactly what you're looking for.''',

    "What if I encounter an error or need help?":
    '''Our system includes friendly error alerts and a detailed "Help" section. For additional support, you can visit the "Info Page" to find guidelines, features explanations, and an FAQ section to assist you.''',

    "How can I join a book club or forum?":
    '''Navigate to the "Community" section where you can browse and join various book clubs and forums. Engage with other readers, participate in discussions, and share your reading experiences.''',

    "What are the system requirements?":
    "Our Library Management System is designed to be lightweight and accessible, requiring only a basic internet connection and a standard web browser or supported device to operate."
}
