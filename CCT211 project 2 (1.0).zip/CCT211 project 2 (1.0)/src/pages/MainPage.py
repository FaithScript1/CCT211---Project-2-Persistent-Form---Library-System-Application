'''

Tianchi Du(Student Number 1008179007)

The MainPage

'''

import tkinter as tk
from tkinter import ttk, messagebox
from src.styles import fonts
from src.pages.BooksPage import BooksPage

class MainPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, background='light gray')  
        self.controller = controller
        
        # Instantiate BooksPage
        self.bookpage = BooksPage()
        
        # Main page title
        label = tk.Label(self, text="Main Page", font=fonts.H1, bg='light gray')  
        label.pack(pady=20)
        
        # Setup search functionality
        self.setup_search()
        
        # Setup navigation buttons
        self.setup_navigation_buttons()
        
        # Add Read Me button
        self.setup_read_me_button()
        
    def setup_search(self):
        """Set up the search bar"""
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(self, textvariable=self.search_var, font=fonts.H1)
        search_entry.pack(pady=10)
        search_button = ttk.Button(self, text="Search", command=self.perform_search)
        search_button.pack(pady=10)
        
    def setup_navigation_buttons(self):
        """Set up navigation buttons"""
        info_page_button = ttk.Button(self, text="Info Page", command=lambda: self.controller.set_frame("InfoPage"))
        info_page_button.pack(pady=10)
        login_button = ttk.Button(self, text="Login / Sign up", command=lambda: self.controller.set_frame("LoginPage"))
        login_button.pack(pady=10)
        library_button = ttk.Button(self, text="Library", command=lambda: self.controller.set_frame("libraryPage"))
        library_button.pack(pady=10)
        books_button = ttk.Button(self, text="Books", command=self.bookpage.create_main_window)
        books_button.pack(pady=10)
        
    def setup_read_me_button(self):
        """Add the Read Me button and its functionality"""
        read_me_button = ttk.Button(self, text="Read Me", command=self.show_read_me)
        read_me_button.pack(pady=10)
        
    def show_read_me(self):
        """Display the Read Me information"""
        read_me_text = """
        Welcome to the Main Page!
        
        Here you can navigate to different pages like Books, Library, and more.
        
        - Use the 'Search' to find specific topics or books.
        - Visit the 'Library' to browse available books.
        - Check out 'Books' for recommendations and new arrivals.
        - Need help? Go to 'Info Page'.
        - To access personal features, use 'Login / Sign up'.
        
        Enjoy exploring!
        """
        messagebox.showinfo("Read Me", read_me_text)
        
    def perform_search(self):
        """Perform the search operation"""
        search_term = self.search_var.get()
        messagebox.showinfo("Search Result", f"Searching for: {search_term}")
