# CCT-211-Project-2

## Getting Started

1. Run the app using run_app.py
2. The app uses the multi-frame framework. Frames are to be created from pages under src/pages/
3. The entry point is src/app.py
4. The databases are under src/database/
5. Styles (e.g. font family) are defined at src/styles/