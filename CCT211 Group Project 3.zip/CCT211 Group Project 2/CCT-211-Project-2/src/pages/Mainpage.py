import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk  # Make sure to install Pillow: pip install Pillow
from src.styles import fonts

class MainPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        
        # Set background image
        self.background_image = ImageTk.PhotoImage(Image.open("path/to/your/background/image.jpg"))
        background_label = tk.Label(self, image=self.background_image)
        background_label.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Ensure label and button texts are visible on top of the background
        label = tk.Label(self, text="Main Page", font=fonts.H1, bg='light gray')  
        label.pack(pady=20)
        
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(self, textvariable=self.search_var, font=fonts.H1)
        search_entry.pack(pady=10)

        search_button = ttk.Button(self, text="Search", command=self.perform_search)
        search_button.pack(pady=10)

        info_page_button = ttk.Button(self, text="Info Page", command=lambda: controller.set_frame("InfoPage"))
        info_page_button.pack(pady=10)
        
        login_button = ttk.Button(self, text="Login / Sign up", command=lambda: controller.set_frame("LoginPage"))
        login_button.pack(pady=10)
        
        library_button = ttk.Button(self, text="Library", command=lambda: controller.set_frame("libraryPage"))
        library_button.pack(pady=10)
        
        # Load and display an image on the main page
        self.page_image = ImageTk.PhotoImage(Image.open("path/to/your/image.jpg"))  # Load the image
        image_label = tk.Label(self, image=self.page_image, bg='light gray')
        image_label.pack(pady=20)  # Display the image

    def perform_search(self):
        search_term = self.search_var.get()
        messagebox.showinfo("Search Result", f"Searching for: {search_term}")
